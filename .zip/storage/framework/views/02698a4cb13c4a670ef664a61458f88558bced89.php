<?php $__env->startPush('custom-css'); ?>
    <style>
        .product-image {
            max-height: 100px;
        }

        #cart_mobile a {
            color: black;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('page_conent'); ?>

    <div class="main-content-wrapper home-page">
        <div class="wrapper-container p-top-15">
            
            <div id="carouselExampleIndicators" class="carousel slide mt-2" data-bs-ride="true">
                <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active"
                        aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1"
                        aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2"
                        aria-label="Slide 3"></button>
                </div>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?php echo e(asset('assets/frontend/images/slider/1.jpg')); ?>" class="d-block w-100" alt="...">
                    </div>

                    <div class="carousel-item">
                        <img src="<?php echo e(asset('assets/frontend/images/slider/2.jpg')); ?>" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('assets/frontend/images/slider/3.jpg')); ?>" class="d-block w-100" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>

            
            <div class="">
                <div class="d-grid gap-2 py-3">
                    <button class="btn btn-primary rounded-0 py-2" style="text-align: left" type="button"><h4 class="m-0"><i class="fa-solid fa-list"></i> All Products</h4></button>
                </div>

                <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3">

                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col">
                            <div class="card shadow-sm pb-3">
                                <a href="<?php echo e(route('product_details', [$product->id])); ?>">
                                    <img class="bd-placeholder-img card-img-top img<?php echo e($product->id); ?>" src='<?php echo e(asset("$product->photo")); ?>' alt="<?php echo e($product->title); ?>" title="<?php echo e($product->title); ?>" width="100%" height="225">
                                    <div class="card-body text-center">
                                        <h5 class="card-title text-dark mb-0 title<?php echo e($product->id); ?>"><?php echo e($product->title); ?></h5>
                                    </div>
                                </a>
                                <div class="text-center">
                                    <div class="d-flex justify-content-center align-items-center mb-3">
                                        <div class="btn-group ">
                                            <button type="button" class="btn btn-sm btn-outline-secondary text-danger dis-price<?php echo e($product->id); ?>">৳ <?php echo e(en2bn($product->price - ($product->discount ?? 0))); ?></button>
                                            <button type="button" style="text-decoration: line-through;" class="btn btn-sm btn-outline-secondary price<?php echo e($product->id); ?>">৳ <?php echo e(en2bn($product->price)); ?></button>
                                        </div>
                                    </div>
                                    <a href="" class="btn btn-primary add-to-cart" id="<?php echo e($product->id); ?>">
                                        <i class="fa fa-cart-plus"></i><span> Add to Cart</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php if(isset($category)): ?>
                            <p class="w-100 text-center">There are no products in <?php echo e($category->title); ?> category</p>
                        <?php else: ?>
                            <p class="w-100 text-center">There are no products</p>
                        <?php endif; ?>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\Second Work\PHP and laravel work\htdocs\taitaikids-laravel2\resources\views/frontend/index.blade.php ENDPATH**/ ?>