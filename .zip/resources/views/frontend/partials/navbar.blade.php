<header style="">
     <div class="header-top-wrapper">
         <div class="wrapper-container">
             <div class="header-top-bar d-flex justify-content-between align-items-center">
                 <div id="search" class="search-bar">
                     <input type="text" name="search" value="" placeholder="Search for products">
                     <button class="fa fa-search-plus" aria-hidden="true"></button>
                 </div>
                  <div class="top-nav-right d-flex">
                        {{--<div class="offers">
                            <a href="#"><i class="fa fa-bookmark"
                                    aria-hidden="true"></i><span>Offers</span></a>
                        </div>
                      <div class="brands">
                          <a href="#"><i class="fa fa-tag"
                                         aria-hidden="true"></i><span>Brands</span></a>
                      </div>--}}

                      {{--@if (Route::has('login'))
                          <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                              @auth
                                  <x-app-layout>

                                  </x-app-layout>
                              @else
                                  <a href="{{ route('login') }}" class="text-sm text-gray-700 dark:text-gray-500 underline">Log in</a>

                                  @if (Route::has('register'))
                                      <a href="{{ route('register') }}" class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                                  @endif
                              @endauth
                          </div>
                      @endif
--}}


                      @if(Route::has('login'))

                          @auth
                              <div class="btn-group">
                                  <button type="button" class="btn dropdown-toggle text-white " data-bs-toggle="dropdown" aria-expanded="false" style="background-color: #006cb4">
                                      <i class="fa-solid fa-lock"></i> Log out / Profile
                                  </button>
                                  <ul class="dropdown-menu text-center dropdown-menu-end">
                                      <a href="#" class="btn btn-default btn-flat float-right btn btn-info text-white"
                                         onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                          <i class="fa-solid fa-right-from-bracket"></i> Log out
                                      </a>
                                      <li><hr class="dropdown-divider"></li>
                                      <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                          @csrf
                                      </form>

                                      <a href="{{ route('login') }}" class="btn btn-primary" style="margin-right: 10px;"><i class="fa fa-sign-in"></i><span> Profile</span></a>

                                  </ul>
                              </div>

                          @else
                          <!-- Example single danger button -->

                              <!-- Example single danger button -->
                              <div class="btn-group">
                                  <button type="button" class="btn dropdown-toggle text-white " data-bs-toggle="dropdown" aria-expanded="false" style="background-color: #006cb4">
                                      <i class="fa-solid fa-lock"></i> Login / Registration
                                  </button>
                                  <ul class="dropdown-menu text-center dropdown-menu-end">
                                      <a href="{{ route('login') }}" class="btn btn-primary" style="margin-right: 10px;"><i class="fa fa-sign-in"></i><span> Login</span></a>
                                      <li><hr class="dropdown-divider"></li>
                                      <a href="{{ route('register') }}" class="btn btn-info text-white"><i class="fa fa-tag" aria-hidden="true"></i><span> Register</span></a>
                                  </ul>
                              </div>

                          @endauth

                      @endif



                        {{--<div class="login">
                            <a href="{{ route('login') }}" class="btn btn-primary" style="margin-right: 10px;"><i class="fa fa-sign-in"></i><span> Login</span></a>
                        </div>
                        <div class="brands">
                            <a href="{{ route('register') }}" class="btn btn-info text-white"><i class="fa fa-tag" aria-hidden="true"></i><span> Register</span></a>
                        </div>--}}
                    </div>
                 <div class="overlay-bg login-popup"></div>
             </div>
         </div>
     </div>
 </header>


