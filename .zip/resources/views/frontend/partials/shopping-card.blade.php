<a href="{{ route('checkout') }}">
    <div class="cart-shopping-btn mc-toggler" id="cart">
        <i class="fa fa-shopping-cart text-light"></i>
        <div class="total-items">
            <p class="count text-light">0 item(s)</p>
        </div>
    </div>
</a>
