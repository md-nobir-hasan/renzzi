<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2021-{{ date('Y') }}
        Design and Developed by |
        <a href="https://euitsols.com" target="_blank">
           Md. Nobir Hasan
        </a>
</footer>
