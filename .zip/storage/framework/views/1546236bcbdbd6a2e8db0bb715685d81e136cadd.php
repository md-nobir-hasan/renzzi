<a href="<?php echo e(route('checkout')); ?>">
    <div class="cart-shopping-btn mc-toggler" id="cart">
        <i class="fa fa-shopping-cart text-light"></i>
        <div class="total-items">
            <p class="count text-light">0 item(s)</p>
        </div>
    </div>
</a>
<?php /**PATH D:\Code\Second Work\PHP and laravel work\htdocs\taitaikids-laravel2\resources\views/frontend/partials/shopping-card.blade.php ENDPATH**/ ?>